    //
    //  RepeatDayViewController.swift
    //  Check It NOW!
    //

import UIKit
import SnapKit
import Then
import RxSwift

    // MARK: - Delegate

protocol RepeatDayViewControllerDelegate: AnyObject {
    func didSelectRepeatDays(_ days: [Int])
}

    // MARK: - RepeatDayViewController

final class RepeatDayViewController: UIViewController {

        // MARK: - Properties

    private let disposeBag = DisposeBag()
    private var selectedDays: Set<Int>
    weak var delegate: RepeatDayViewControllerDelegate?

    private let days = ["일", "월", "화", "수", "목", "금", "토"]

        // MARK: - UI

    private let tableView = UITableView(frame: .zero, style: .insetGrouped).then {
        $0.backgroundColor = UIColor(red: 0.11, green: 0.11, blue: 0.12, alpha: 1)
        $0.separatorColor  = UIColor(white: 0.25, alpha: 1)
        $0.register(UITableViewCell.self, forCellReuseIdentifier: "DayCell")
    }

        // MARK: - Init

    init(selectedDays: [Int] = []) {
        self.selectedDays = Set(selectedDays)
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError() }

        // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.11, green: 0.11, blue: 0.12, alpha: 1)
        title = "반복"
        view.addSubview(tableView)
        tableView.snp.makeConstraints { $0.edges.equalToSuperview() }
        tableView.delegate   = self
        tableView.dataSource = self
    }

        /// 화면이 사라질 때 delegate에 선택 결과 전달 (back 버튼 포함)
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        delegate?.didSelectRepeatDays(Array(selectedDays).sorted())
    }
}

    // MARK: - UITableViewDataSource

extension RepeatDayViewController: UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        days.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell     = tableView.dequeueReusableCell(withIdentifier: "DayCell", for: indexPath)
        let dayIndex = indexPath.row

        var config = cell.defaultContentConfiguration()
        config.text = days[dayIndex]
        config.textProperties.color = .white
        cell.contentConfiguration = config

        cell.backgroundColor = UIColor(red: 0.17, green: 0.17, blue: 0.18, alpha: 1)
        cell.tintColor       = .systemOrange
        cell.accessoryType   = selectedDays.contains(dayIndex) ? .checkmark : .none

        return cell
    }
}

    // MARK: - UITableViewDelegate

extension RepeatDayViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let dayIndex = indexPath.row
        if selectedDays.contains(dayIndex) {
            selectedDays.remove(dayIndex)
        } else {
            selectedDays.insert(dayIndex)
        }
        tableView.reloadRows(at: [indexPath], with: .none)
    }
}
